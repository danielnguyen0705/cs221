import numpy as np   
import nltk
from nltk import sent_tokenize
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB

nltk.download('punkt')
nltk.download("stopwords")

class Model:
	def __init__(self):
		self.classifier = None
		self.vectorizer = None
		self.stoplist = stopwords.words("english")
		self.stoplist.extend(['.', ',', ':', '`', '"', "'", '!', '?', "``", "''"])
    
	def fit(self, Train_Text, Train_Label):
		XPrep = []
		for s in Train_Text:
			X = []
			for sent in sent_tokenize(s):
				for word in word_tokenize(sent):
					if word in self.stoplist:
						continue
					X.append(word)
			XPrep.append(" ".join(X))
	
		self.vectorizer = TfidfVectorizer(max_features=20000, max_df=0.9, min_df=5)
		vTrain = self.vectorizer.fit_transform(XPrep).toarray()
		self.classifier = MultinomialNB()
		self.classifier.fit(vTrain, Train_Label)


	def predict(self, Test_Text):	
		XPrep = []
		for s in Test_Text:
			X = []
			for sent in sent_tokenize(s):
				for word in word_tokenize(sent):
					if word in self.stoplist:
						continue
					X.append(word)
			XPrep.append(" ".join(X))
	
		vTest = self.vectorizer.transform(XPrep).toarray()
		YTest = self.classifier.predict(vTest)
		return YTest
