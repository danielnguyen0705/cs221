import numpy as np
import pickle
class POSTagger:
    def __init__(self):
        self.Dict = {}
        self.DefaultPOS = "NN"

    def fit(self, Sents, POSs):
        Words = {}
        for i in range(len(Sents)):
            for j in range(len(Sents[i])):
                word = Sents[i][j]
                if Words.get(word) == None:
                    Words[word] = {}
                tags = Words[word]
                tag = POSs[i][j]
                if tags.get(tag) == None:
                    tags[tag] = 0
                else:
                    tags[tag] += 1
                Words[word] = tags
        for word in Words:
            tags = Words[word]
            stag = "NN"
            freq = 0
            for tag in tags:
                if tags[tag] > freq:
                    freq = tags[tag]
                    stag = tag
            self.Dict[word] = stag
            
    def predict(self, Sents):
        results = []
        for sent in Sents:
            pos = []
            for word in sent:
                if self.Dict.get(word) == None:
                    pos.append(self.DefaultPOS)
                else:
                    pos.append(self.Dict[word])
            results.append(pos)
        return results

    def load():
        return pickle.load(open("model.mdl", "rb"))
        
    def save(self):
        return pickle.dump(self, open("model.mdl", "wb"))
        